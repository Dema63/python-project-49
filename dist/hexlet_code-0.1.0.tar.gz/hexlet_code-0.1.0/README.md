### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dema63/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Dema63/python-project-49/actions)

<a href="https://codeclimate.com/github/Dema63/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/15b510d79321bd73ff8d/maintainability" /></ai

https://asciinema.org/a/QwlKyNosSsw7IiYrXXwhOn60Q

https://asciinema.org/a/ogLjrMQjRaaovDxv01VSsjXD5

https://asciinema.org/a/4t8sHpHMGVAL5fRUqJyYE9asH

https://asciinema.org/a/MZQ2pbeOO728SmqR31UlcQPTa

https://asciinema.org/a/PLzmFthxFofXDykIAT8Y13pY8

https://asciinema.org/a/vCAG2fZ9yHkOcjuJfzbHoCI8i

https://asciinema.org/a/Fr96usW28fKbySgZmFCszvjQZ

https://asciinema.org/a/F84Us6Pp9rP7FMIubePvSF4II

https://asciinema.org/a/X884wkv6oW9SfYAOEWa78djS1

https://asciinema.org/a/iYS2NQ97oyCgaMNE5AzKKYqCv
>
